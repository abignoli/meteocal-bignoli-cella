/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.meteocal.business.entities.shared;

/**
 *
 * @author ate
 */
public class TableDictionary {
    public static final String TABLE_EVENT = "EVENT";
    public static final String TABLE_INVITATION = "INVITATION";
    public static final String TABLE_NOTIFICATION = "NOTIFICATION";
    public static final String TABLE_NOTIFICATION_VIEW = "NOTIFICATIONVIEW";
    public static final String TABLE_USER = "USER_TABLE";
    public static final String TABLE_WEATHER_FORECAST = "WEATHERFORECAST";
}
