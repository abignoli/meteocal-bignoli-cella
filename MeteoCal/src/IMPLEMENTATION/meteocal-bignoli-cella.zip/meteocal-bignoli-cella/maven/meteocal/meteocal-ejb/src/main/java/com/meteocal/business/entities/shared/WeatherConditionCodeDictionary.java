/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.meteocal.business.entities.shared;

/**
 *
 * @author ate
 */
public class WeatherConditionCodeDictionary {
    public static final int SUN_CODE = 0;
    public static final int RAIN_CODE = 1;
    public static final int SNOW_CODE = 2;
    public static final int CLOUDS_CODE = 3; 
    public static final int NOT_AVAILABLE_CODE = 4; 
}
