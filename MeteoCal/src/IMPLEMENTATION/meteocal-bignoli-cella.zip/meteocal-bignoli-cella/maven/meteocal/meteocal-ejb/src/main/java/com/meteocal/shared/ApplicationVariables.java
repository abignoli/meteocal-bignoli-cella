/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.meteocal.shared;

/**
 *
 * @author AB
 */
public class ApplicationVariables {
    public static final String OPENWEATHERMAP_API_KEY = "3b8eccdf67c3fa73d929297e99ed204a";
}
